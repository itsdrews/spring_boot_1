package learner.drew.ScreenMatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenMatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
